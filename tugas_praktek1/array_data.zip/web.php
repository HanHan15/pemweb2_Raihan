<?php
    echo '<h1>SELAMAT BELAJAR PHP</h1>';
    echo $name;
?>